module.exports = [
  'DivinationCard',
  'UniqueArmour',
  'UniqueAccessory',
  'UniqueWeapon',
  'Prophecy',
  'UniqueMap',
  'SkillGem',
  'UniqueFlask',
  'UniqueJewel',
];