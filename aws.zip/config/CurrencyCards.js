module.exports = [
  {
    Name: 'The Wrath',
    Reward: 'Chaos Orb',
    Amount: 10,
  },
  {
    Name: 'Abandoned Wealth',
    Reward: 'Exalted Orb',
    Amount: 3,
  }, {
    Name: "The Saint's Treasure",
    Reward: 'Exalted Orb',
    Amount: 2,
  }, {
    Name: 'The Hoarder',
    Reward: 'Exalted Orb',
    Amount: 1,
  }, {
    Name: 'The Sephirot',
    Reward: 'Divine Orb',
    Amount: 10,
  }, {
    Name: 'House of Mirrors',
    Reward: 'Mirror of Kalandra',
    Amount: 1,
  }, {
    Name: 'Seven Years Bad Luck',
    Reward: 'Mirror Shard',
    Amount: 1,
  },
];
